<?php session_start();
$filename = 'configFile.txt';
$user_file = $_REQUEST["username"].".txt";
$_SESSION["username"] = $_REQUEST["username"];

//if the file exists, greet the user
if (file_exists($user_file))
{
    echo "Welcome back, " . $_SESSION["username"];
}
//otherwise, create a new file for the user and thank them for registering
else
{
    $file = fopen($user_file, 'w');
    fwrite($file, $_POST["pass"]."\n");
    fwrite($file, $_SESSION["gold"]."\n");
    fclose($file);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <title>Egg Farm</title>
    <style type="text/css">

        .panel
        {
            background: lightskyblue;
            height: 530px;
            width: 400px;
            font-family: "American Typewriter";
            text-align: center;
        }

        div.sign
        {
            background-image: url("./pricetag.png");
            padding: 25px;
            margin-bottom: 50px;
            position: relative;
            width: 150px;
            font-family: "Chalkboard";
            font-size: 1.5em;
        }
    </style>
</head>

<body>

<div class="panel">
    <h1>Welcome to EggFarm, <?php echo $_SESSION["username"]; ?>!</h1>
    <h3> You have <?php echo $_SESSION["gold"]; ?> gold </h3>
    <div class="sign">Egg Store</div> <br>
    <div class="sign">My Barn</div> <br>
    <div class="sign">Scoreboard</div>
</div>

</body>
</html>